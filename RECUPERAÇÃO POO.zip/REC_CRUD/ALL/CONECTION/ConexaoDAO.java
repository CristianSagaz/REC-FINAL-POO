package CONECTION;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

import src.aluno;


public class ConexaoDAO {

	
	private Connection connection;

	
	public Connection conectaBD() {
		Connection conn = null;
				
		try {
			String url = "jdbc:mysql://localhost:3306/BancoUM?user=root&password=";
			conn = DriverManager.getConnection(url);
			
		}catch(SQLException erro) {
			JOptionPane.showMessageDialog(null,"ConexaoDAO");
		}
		return conn;
	}
		
	public void cadastrar(aluno Aluno) {
				try {
			String sql = "INSERT INTO ALUNO(nome, idade, matricula, serie) VALUES (?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(sql);

			statement.setString(1, Aluno.getNome());	
			statement.setInt(2, Aluno.getIdade());
			statement.setInt(3, Aluno.getMatricula());	
			statement.setString(4, Aluno.getSerie());
			statement.execute();
			
			connection.commit();
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		
	}
	
	public boolean buscar(long id) {
		aluno Aluno = new aluno();

		String sql = "SELECT * FROM ALUNO WHERE id =" + id;

		PreparedStatement statement = connection.prepareStatement(sql);

		ResultSet resultado = statement.executeQuery();

		while (resultado.next()) {
			Aluno.setNome(resultado.getString("nome"));
			Aluno.setIdade(resultado.getInt("idade"));
			Aluno.setMatricula(resultado.getInt("matricula"));
			Aluno.setSerie(resultado.getString("serie"));

		}

		return Aluno;
	}
	public boolean editar(long id) {
		try {
			String sql = "UPDATE ALUNO SET nome = ? WHERE id = " + aluno.getId();
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setString(1, aluno.getNome());
			statement.execute();
			connection.commit();
		} catch (SQLException e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
	}
	public void deletar(long id) {
		try {
			String sql = "DELETE FROM ALUNO WHERE id = "+id;
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.execute();
			connection.commit();
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		}	
	}
	
	
	
}
