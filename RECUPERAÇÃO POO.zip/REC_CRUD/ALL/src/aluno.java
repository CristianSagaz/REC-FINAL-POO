package src;

public class aluno extends pessoa{
		
		String id;
		String serie;
		int matricula;
		
		public String getId(){
			return id;
		}
		public Void setId(String id){
			this.id = id;
			return null;
		}
		public String getNome(){
			return nome;
		}
		public Void setNome(String nome){
			this.nome = nome;
			return null;
		}
		public int getIdade(){
			return idade;
		}
		public Void setIdade(int idade){
			this.idade = idade;
			return null;
		}
		
		public String getSerie(){
			return serie;
		}
		public Void setSerie(String serie){
			this.serie = serie;
			return null;
		}
		public int getMatricula(){
			return matricula;
		}
		public Void setMatricula(int matricula){
			this.matricula = matricula;
			return null;
		}
	}
