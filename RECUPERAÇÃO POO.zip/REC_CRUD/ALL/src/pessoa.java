package src;

public class pessoa {
	String nome;
	int idade;
}
