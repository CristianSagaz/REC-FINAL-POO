package src;


public class professor extends pessoa{
	
	String matricula;
	String turno;
	
	public String getNome(){
		return nome;
	}
	public Void setNome(String nome){
		this.nome = nome;
		return null;
	}
	public int getIDade(){
		return idade;
	}
	public Void setIdade(int idade){
		this.idade = idade;
		return null;
	}
		
	public String getTurno(){
		return turno;
	}
	public Void setTurno(String turno){
		this.turno = turno;
		return null;
	}
	public String getMatricula(){
		return matricula;
	}
	public Void setMatricula(String matricula){
		this.matricula = matricula;
		return null;
	}
	
}
